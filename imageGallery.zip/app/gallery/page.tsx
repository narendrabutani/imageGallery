import GalleryContainer from "@ImageGallery/components/GalleryContainer";
export default function Gallery() {
  return <GalleryContainer />;
}
